/*
============================================================================

WHAT WAS THE ISSUE?

The for-loop finishes before we dealt with the time-out function. 
As a result, the gate #5 shows up everytime the program runs. 

Therefore, in order for the program to display each gate number in sequence,
one solution is to have an outer loop that calls the setTimeout function. 
That way, we can use one iteration value for each setTimeout function. 

============================================================================
*/

/*
DESCRIPTION:
    This function prints out to the console the gatenumber

PARAMETER:
    gateNumber: An integer that holds the gate number
*/
function openGate(gateNumber) {
    console.log(`Opening Gate #${gateNumber}`);
}

/*
DESCRIPTION:
    This function displays the appropriate gate number in 1000 millisecond
    time intervals. 

PARAMETER:
    openerFunction: A function that prints that gate number to console
    i: An integer value for gate number
*/
function openAll(openerFunction, i) {

    //Timeout function that runs every 1000 milliseconds
    setTimeout(() => {
        openerFunction(i);
    }, i * 1000);

}

//Loop to call the openAll function 5 times 
//where 5 signifies the number of gates that are available
for (var i = 0; i < 5; i++){
    openAll(openGate, i);
}
            







