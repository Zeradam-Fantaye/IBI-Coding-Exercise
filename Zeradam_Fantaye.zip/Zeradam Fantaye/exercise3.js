
/*
DESCRIPTION:
    This function calculates a car's average hourly speed between each
    sample within the array "d" and a given interval time "s". Then, 
    the function returns the maximum speed that it determines for each sample. 
    It returns the mathematical floor of the maximum speed observed.

PARAMETERS:
    s: The interval time used to determine a distance traveled (Integers)
    d: An array of sample data for measured distance (Number)

*/
let exercise3 = (s, d) => {

    let i;              // Walker for the array
    let maxSpeed = 0;   // The maximum speed determined
    let speed;          // The speed calculated for each sample

    //Condition to check for a proper array value
    if (d.length <= 1)
        return 0;

    //Loop to calculate the speed of each sample, and
    //determine the maximum speed calculated
    for (i = 1; i < d.length; i++){
        
        //Calucluate the speed
        speed = ((d[i] - d[i - 1]) * 3600) / s;

        //Condition to determine the maximum speed
        if (speed > maxSpeed)
            maxSpeed = speed;
    }

    //Return the mathematical floor of determined max speed
    return Math.floor(maxSpeed);
}

module.exports = exercise3;