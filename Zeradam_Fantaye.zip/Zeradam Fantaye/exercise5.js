var myObj = {}; 
var request = require("request");

/*
DESCRIPTION:
    This function requests to fetch data from an API. From the 
    selected API, it will fetch a random random joke. As a result, 
    it will return a promise either resolved or rejected

PARAMETERS:
    None

*/
myObj.joke = () => {
    
    return new Promise((resolve, reject) => {
        
            var options = {
                url : `https://icanhazdadjoke.com/`,
                method : "GET",
                headers: {
                    "Accept" : "application/json"
                    }
            };
            
            request(options, function(err, res, body){
                
                //Condition to check validity
                if(err){
                    reject(err);
                }else{
                    var body = JSON.parse(body);
                    var text = body.joke;
                    resolve(text);
                }
            })
    })
}

/*
DESCRIPTION:
    This function requests to fetch data from an API. From the 
    selected API, it will fetch a joke by locating it using the joke ID 
    that is being passed to it. As a result, it will return a promise 
    either resolved or rejected

PARAMETERS:
    joke_id: a string that is used to identify a specific joke

*/
myObj.getJokeById = (joke_id) => {
    
    return new Promise((resolve, reject) => {
        
            var options = {
                url : `https://icanhazdadjoke.com/j/${joke_id}`,
                method : "GET",
                headers: {
                    "Accept" : "application/json"
                    }
            };
            
            request(options, function(err, res, body){
                
                //Condition to check validity
                if(err){
                    reject(err);
                }else{
                    var body = JSON.parse(body);
                    var text = body.joke;
                    resolve(text);
                }
            })
    })
}

/*
DESCRIPTION:
    This function request to fetch data from an API. From the 
    selected API, it will fetch all jokes that has a specific term. 
    As a result, it will return a promise either resolved or rejected

PARAMETERS:
    term: A string that is used to identify jokes with the same word in it. 

*/
myObj.searchForJokesWith = (term) => {
    
    return new Promise((resolve, reject) => {
        
            var options = {
                url : `https://icanhazdadjoke.com/search?term=${term}`,
                method : "GET",
                headers: {
                    "Accept" : "application/json"
                    }
            };
            
            request(options, function(err, res, body){
                
                //Condition to check validity
                if(err){
                    reject(err);
                }else{
                    var objResult = JSON.parse(body);
                    var arrayResult = objResult.results;
                    resolve(arrayResult);
                }
            })
    })
}

module.exports = myObj;