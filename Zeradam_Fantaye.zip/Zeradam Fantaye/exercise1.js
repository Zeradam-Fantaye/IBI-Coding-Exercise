
/*
DESCRIPTION:
    This function finds the index n where the sum
    of the elements in the array to the left of
    n is equal to the sum of the elements in the
    array to the right of n.

PARAMETER:
    arr: An integer array to be detected
*/
let exercise1 = ( arr ) => {
    let i;                 // Walker in the array
    let totalSum = 0;      // Total sum of all array elements
    let sumToTheLeft = 0;  // Total sum to the left of index n

    //Loop to calculate total sum
    for (i = 0; i < arr.length; i++){
        totalSum += arr[i];
    }

    //Loop to determine the required index
    for (i = 0; i < arr.length; i++){
        //Subtracting from total sum to compare with the left sum
        totalSum -= arr[i];        

        //Condition to check if "i" is the right index
        if(sumToTheLeft === totalSum){
            //console.log("i = ", i);
            return i;
        }
        
        //Adding all sum to the left of index i
        sumToTheLeft += arr[i];
    }

    return -1;
}

module.exports = exercise1;