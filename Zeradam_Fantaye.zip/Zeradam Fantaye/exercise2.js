
/*
DESCRIPTION:
    This function calculates the sum of the
    digits of a given integer until it reaches
    a single digit number

PARAMETER:
    num: An integer number to be detected   
*/
let exercise2 = (num) => {
    let sum = 0;   // Calculates the total sum
    let peelNum;   // The last most digit of an integer

    //Loop to determine the last one digit
    while (num > 0 || sum > 9){

        //Condition to keep it iterate in the loop. 
        if (num === 0){
            num = sum; // A new num value will set for next round.

            sum = 0;   // Sum will re-initialize to zero 
                       // for the new sum digits(more than 1).
        }

        //Determine the last most digit
        peelNum = num % 10;

        //Sum up the last peeled digit
        sum += peelNum;

        //Reduce num to a lesser digit
        num = Math.floor(num / 10); 
    }

    //Return a one-digit sum
    return sum;
}

module.exports = exercise2;